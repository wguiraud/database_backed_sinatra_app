require 'minitest/autorun'
require 'rack/test'
require 'pry'

ENV['RACK_ENV'] = 'test'

require_relative '../todo'

class TodoTest < Minitest::Test
  include Rack::Test::Methods

  def app
    Sinatra::Application
  end

  def test_loading_home_page
    get '/'
    assert_equal 302, last_response.status

    get last_response['location']
    assert_equal 200, last_response.status
  end

end