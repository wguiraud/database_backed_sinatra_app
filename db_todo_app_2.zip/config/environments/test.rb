# frozen_string_literal: true

# config/environments/test.rb
ENV['SESSION_SECRET'] =
  '3dd6abdf3a72c98b9c7316faedc475b671b43026d3b92778122cbebcd6f3dd25d5a739be99731e4827c631bf9aef146657800be2ceb27f9f24bd9f5a24f11856'
# Add other test-specific configurations
